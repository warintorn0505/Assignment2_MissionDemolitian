using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(Rigidbody))]
public class StrongBlock : MonoBehaviour
{
    public int health = 3;
    public float strongMass = 8f;
    private Rigidbody rb;

    void Start()
    {
        rb = GetComponent<Rigidbody>();
        rb.mass = strongMass;
    }

    void OnCollisionEnter(Collision collision)
    {
        Projectile proj = collision.gameObject.GetComponent<Projectile>();

        if (proj != null)
        {
            health--;

            if (health <= 0)
            {
                Destroy(gameObject);
            }
        }
    }
}