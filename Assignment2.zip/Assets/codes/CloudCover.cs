using System.Collections;
using System.Collections.Generic;
using UnityEngine;
 
public class CloudCover : MonoBehaviour {
     [Header( "Inscribed" )]
     public Sprite[]  cloudSprites;
     public int       numClouds  = 40; // a
     public Vector3   minPos     = new Vector3( -20, -5, -5 );
     public Vector3   maxPos     = new Vector3( 300, 40,  5 );
     [Tooltip("For scaleRange, x is the min value, and y is the max value.")]
     public Vector2   scaleRange = new Vector2( 1, 4 );                        // b
 
     void Start() {
         Transform parentTrans = this.transform;
         GameObject cloudGO;
         Transform cloudTrans;
         SpriteRenderer sRend;
         float scaleMult;
         for ( int i = 0; i < numClouds; i++ ) {
             // Create a new GameObject (from scratch!) and get its Transform
             cloudGO = new GameObject();                                       // c
             cloudTrans = cloudGO.transform;
             sRend = cloudGO.AddComponent<SpriteRenderer>();                   // d
             
             int spriteNum = Random.Range( 0, cloudSprites.Length );           // e
             sRend.sprite = cloudSprites[spriteNum];
 
             cloudTrans.position = RandomPos();                                // f
             cloudTrans.SetParent( parentTrans, true );
 
             scaleMult = Random.Range( scaleRange.x, scaleRange.y );           // b
             cloudTrans.localScale = Vector3.one * scaleMult;
         }
     }
     
     Vector3 RandomPos() {                                                     // f
         Vector3 pos = new Vector3(); 
         pos.x = Random.Range( minPos.x, maxPos.x );
         pos.y = Random.Range( minPos.y, maxPos.y );
         pos.z = Random.Range( minPos.z, maxPos.z );
         return pos;
     }
 }