using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Slingshot : MonoBehaviour
{
    [Header("Inscribed")]
    public GameObject projectilePrefab;
    public GameObject projLinePrefab;
    public float velocityMult = 10f;

    [Header("Shots")]
    public int shotsLeft = 5;
    public Text shotsText;

    [Header("Sound")]
    public AudioClip launchSound;
    [Range(0f, 1f)]
    public float launchVolume = 1f;

    [Header("Dynamic")]
    public GameObject launchPoint;
    public Vector3 launchPos;
    public GameObject projectile;
    public bool aimingMode;

    void Awake()
    {
        Transform launchPointTrans = transform.Find("LaunchPoint");
        launchPoint = launchPointTrans.gameObject;
        launchPoint.SetActive(false);
        launchPos = launchPointTrans.position;
    }

    void Start()
    {
        UpdateShotsUI();
    }

    public void ResetShots()
    {
        shotsLeft = 5;
        UpdateShotsUI();
    }

    void UpdateShotsUI()
    {
        if (shotsText != null)
        {
            shotsText.text = "Shots: " + shotsLeft;
        }
    }

    void Update()
    {
        if (!aimingMode) return;

        Vector3 mousePos2D = Input.mousePosition;
        mousePos2D.z = -Camera.main.transform.position.z;

        Vector3 mousePos3D = Camera.main.ScreenToWorldPoint(mousePos2D);

        Vector3 mouseDelta = mousePos3D - launchPos;

        float maxMagnitude = this.GetComponent<SphereCollider>().radius;
        if (mouseDelta.magnitude > maxMagnitude)
        {
            mouseDelta.Normalize();
            mouseDelta *= maxMagnitude;
        }

        Vector3 projPos = launchPos + mouseDelta;
        projectile.transform.position = projPos;

        if (Input.GetMouseButtonUp(0))
        {
            aimingMode = false;

            Rigidbody projRB = projectile.GetComponent<Rigidbody>();
            projRB.isKinematic = false;
            projRB.collisionDetectionMode = CollisionDetectionMode.Continuous;
            projRB.linearVelocity = -mouseDelta * velocityMult;

            // play launch sound safely
            if (launchSound != null && Camera.main != null)
            {
                AudioSource.PlayClipAtPoint(
                    launchSound,
                    Camera.main.transform.position,
                    launchVolume
                );
            }

            FollowCam.SWITCH_VIEW(FollowCam.eView.both);
            FollowCam.POI = projectile;

            Instantiate<GameObject>(projLinePrefab, projectile.transform);

            projectile = null;

            MissionDemolition.SHOT_FIRED();
        }
    }

    void OnMouseEnter()
    {
        launchPoint.SetActive(true);
    }

    void OnMouseExit()
    {
        launchPoint.SetActive(false);
    }

    void OnMouseDown()
    {
        if (shotsLeft <= 0)
        {
            return;
        }

        aimingMode = true;

        shotsLeft--;
        UpdateShotsUI();

        projectile = Instantiate(projectilePrefab) as GameObject;
        projectile.transform.position = launchPos;
        projectile.GetComponent<Rigidbody>().isKinematic = true;
    }
}